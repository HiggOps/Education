<?php
    $connect = new mysqli("localhost","root","","11_3_szablon");
?>